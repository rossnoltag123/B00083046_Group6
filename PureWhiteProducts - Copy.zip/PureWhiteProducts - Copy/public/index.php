<?php

use RossNolan\MainController;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../app/setup.php';
require_once __DIR__ . '/../app/config_db.php';

$action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_STRING );

if('about'== $action){
    $mController->aboutAction($twig);
} else if('contact'== $action){
    $mController->contactAction($twig);
} else if('list'== $action){
    $mController->listAction($twig);
} else if('sitemap'== $action){
    $mController->sitemapAction($twig);
} else{
    $mController->indexAction($twig);
}

