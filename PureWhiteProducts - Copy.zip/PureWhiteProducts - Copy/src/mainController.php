<?php

namespace RossNolan;
/**
 * This is the main controller for my page methods
 * Class MainController
 * @package RossNolan
 */
class MainController
{
    /**
     * about page
     * @param \Twig_Environment $twig
     */
    public function aboutAction(\Twig_Environment $twig)
    {
        $array=[];
        $template = 'about';
        $outPut= $twig->render ($template . '.php.twig');
        print $outPut;

    }

    /**
     *  contact page
     * @param \Twig_Environment $twig
     */
    public function contactAction(\Twig_Environment $twig)
    {
        $array=[];
        $template = 'contact';
        $outPut= $twig->render($template . '.php.twig');
        echo $outPut;
    }

    /**
     * index page (Home)
     * @param \Twig_Environment $twig
     */
    public function indexAction(\Twig_Environment $twig)
    {
        $array=[];
        $template = 'index';
        $outPut= $twig->render($template . '.php.twig');
        echo $outPut;
    }

    /**
     * list page
     * @param \Twig_Environment $twig
     */
    public function listAction(\Twig_Environment $twig)
    {
        $products = \RossNolan\Product::getAll();

        $array=[
            'products'=>$products,
        ];

        $template = 'list';
        $outPut= $twig->render($template . '.php.twig', $array);
        echo $outPut;
    }

    /**
     * sitemap page
     * @param \Twig_Environment $twig
     */
    public function sitemapAction(\Twig_Environment $twig)
    {
        $array=[];
        $template = 'sitemap';
        $outPut= $twig->render($template . '.php.twig');
        echo $outPut;
    }
}