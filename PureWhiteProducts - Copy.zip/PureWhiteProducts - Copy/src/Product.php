<?php

namespace RossNolan;

use Mattsmithdev\PdoCrud\DatabaseTable;

/**
 * This is the product class
 * Class Product
 * @package RossNolan
 */
class Product extends DatabaseTable
{
    /**
     * id string
     * @var string
     */
    private $id;
    /**
     * description string
     * @var string
     */
    private $description;
    /**
     * price string
     * @var string
     */
    private $price;

    /**
     * get price method
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * set price method
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }
    /**
     * get id method
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * set id method
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     *set description method
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * get description method
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }
}