<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'WhiteProducts');
define('DB_PASS', '');
define('DB_NAME', 'products');

