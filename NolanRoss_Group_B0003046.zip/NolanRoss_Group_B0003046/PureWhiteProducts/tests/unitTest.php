<?php

namespace RossNolan;

class unitTest extends \PHPUnit_Framework_TestCase
{
    public function testItWorks()
    {
        $this->assertEquals(true, true);
    }

    public function testCanCreateProduct()
    {
        //arrange
        $p= new Product();

        //act

        //assert
        $this->assertNotNull($p);
    }

    public function testGetIdNonNullAfterProductCreated()
    {
        //arrange
        $p = new Product();

        //act
        $id = $p->getId();

        //assert
        $this->assertNotNull($id);
    }

    public function testGetIdMinusOneAfterProductCreated()
    {
        //arrange
        $p = new Product();
        $expectedResult = -1;

        //act
        $result = $p->getId();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetIdAfterSetIdTwo()
    {
        //arrange
        $p = new Product();
        $expectedResult = 2;
        $p->setId(2);
        //act
        $result = $p->getId();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetDescriptionAfterSetDescriptionExpensive()
    {
        //arrange
        $p = new Product();
        $expectedResult = "expensive";
        $p->setDescription("expensive");

        //act
        $result = $p->getDescription();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetDescriptionAfterSetDescriptionNotExpensive()
    {
        //arrange
        $p = new Product();
        $expectedResult = "NotExpensive";
        $p->setDescription("NotExpensive");

        //act
        $result = $p->getDescription();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetDescriptionAAfterObjectCreated()
    {
        //arrange
        $p = new Product();
        $expectedResult = 'a';

        //act
        $result = $p->getDescription();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetPriceAfterSetPriceZero()
    {
        //arrange
        $p = new Product();
        $expectedResult = 00.00;
        $p->setPrice(00.00);

        //act
        $result = $p->getPrice();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetPriceAfterSetPriceTen()
    {
        //arrange
        $p = new Product();
        $expectedResult = 10.00;
        $p->setPrice(10.00);

        //act
        $result = $p->getPrice();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetPriceZeroZeroAfterObjectCreated()
    {
        //arrange
        $p = new Product();
        $expectedResult = 00.00;

        //act
        $result = $p->getPrice();

        //assert
        $this->assertNotNull($expectedResult, $result);
    }

    public function testGetPriceZeroAfterSetPriceNegativeTwo()
    {
        //arrange
        $p = new Product();
        $expectedResult = 00.00;
        $p->setPrice(1.50);
        $p->setPrice(-2.00);

        //act
        $result = $p->getPrice();

        //assert
        $this->assertEquals($expectedResult, $result);
    }

    /**
     * @param $priceToSet
     * @param $expectedResult
     * @dataProvider dataForPriceTesting
     */
    public function testGetPriceMatchesExpectedAfterSetPrice($priceToSet, $expectedResult)
    {
        //arrange
    $p = new Product();
        $p->setPrice($priceToSet);

    //act
    $result = $p->getPrice();

    //assert
    $this->assertEquals($expectedResult, $result);
    }

    public function dataForPriceTesting()
    {
        return [
            [00.00,00.00],
            [10.00,10.00]
        ];
    }
}
