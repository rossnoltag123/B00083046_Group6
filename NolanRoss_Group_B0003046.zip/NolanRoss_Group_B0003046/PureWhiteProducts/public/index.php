<?php
session_start();
use RossNolan\MainController;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../app/setup.php';
require_once __DIR__ . '/../app/config_db.php';

$action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_STRING);

if ('about'== $action) {
    $mController->aboutAction($twig);
} elseif ('contact'== $action) {
    $mController->contactAction($twig);
} elseif ('list'== $action) {
    $mController->listAction($twig);
} elseif ('sitemap'== $action) {
    $mController->sitemapAction($twig);
} elseif ('signup'== $action) {
    $mController->signupAction($twig);
} elseif ('processLogin'== $action) {
    $mController->processLoginAction($twig);
} elseif ('logout'== $action) {
    $mController->logoutAction($twig);
} elseif ('login'== $action) {
    $mController->processLoginAction($twig);
} else {
    $mController->indexAction($twig);
}
