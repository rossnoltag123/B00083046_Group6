<?php
/**
 * the name space
 */
namespace RossNolan;
/**
 * use of class`s
 */
use Mattsmithdev\PdoCrud\DatabaseTable;

/**
 * Class User this is my product class
 * @package RossNolan this is my user class
 */
class User extends DatabaseTable
{
    /**
     * password hased for storage
     * @var varchar
     */
  private $password;

    /**
     * get password
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * set password
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * name for user
     * @var string
     */
    private $name;

    /**
     * surname for user
     * @var string
     */
    private $surname;

    /**
     * get name for user
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * set name for user
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * get surname
     * @return mixed
     */
    public function getSurname()
    {
        return $this->surname;
    }

    /**
     * set surname
     * @param mixed $surname
     */
    public function setSurname($surname)
    {
        $this->surname = $surname;
    }
}
