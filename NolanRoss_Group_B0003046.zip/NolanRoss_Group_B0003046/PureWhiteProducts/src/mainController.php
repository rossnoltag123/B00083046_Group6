<?php
/**
 * the name space
 */
namespace RossNolan;

/**
 * This is the main controller for my page methods
 * Class MainController this is the main controller for all the meothds
 * @package RossNolan this is my main controller
 */
class mainController
{
    /**
     * about page
     * @param \Twig_Environment $twig
     */
    public function aboutAction(\Twig_Environment $twig)
    {
        $array = [];
        $template = 'about';
        $outPut = $twig->render($template . '.php.twig');
        print $outPut;
    }

    /**
     *  contact page
     * @param \Twig_Environment $twig
     */
    public function contactAction(\Twig_Environment $twig)
    {
        $array = [];
        $template = 'contact';
        $outPut = $twig->render($template . '.php.twig');
        echo $outPut;
    }

    /**
     * index page (Home)
     * @param \Twig_Environment $twig
     */
    public function indexAction(\Twig_Environment $twig)
    {
        $array = [];
        $template = 'index';
        $outPut = $twig->render($template . '.php.twig');
        echo $outPut;
    }

    /**
     * process login page
     * @param \Twig_Environment $twig
     */
    public function processLoginAction(\Twig_Environment $twig)
    {
        $isLoggedIn=false;

        $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
        $password = filter_input(INPUT_POST, 'pword', FILTER_SANITIZE_STRING);

        $hashedCorrectPassword = password_hash('admin', PASSWORD_DEFAULT);

        if (('admin' == $username) && password_verify($password, $hashedCorrectPassword)) {
            $isLoggedIn = true;
        }

        if ($isLoggedIn) {
            $users = \RossNolan\User::getAll();
            $arrayArgs = [
               'users' => $users
           ];
            $template = 'displayUsers';
            $outPut = $twig->render($template . '.php.twig', $arrayArgs);
            echo $outPut;

            $_SESSION['user']=$username;
        } else {
            if (('' == $username)) {
                $template = 'processLogin';
                $outPut = $twig->render($template . '.php.twig');
                echo $outPut;
            } else {
                $template = 'message';
                $outPut = $twig->render($template . '.php.twig');
                echo $outPut;
            }
        }
    }

    /**
     * signup page
     * @param \Twig_Environment $twig
     */
    public function signupAction(\Twig_Environment $twig)
    {
        $firstname = filter_input(INPUT_POST, 'firstname', FILTER_SANITIZE_STRING);
        $srname = filter_input(INPUT_POST, 'srname', FILTER_SANITIZE_STRING);
        $pword =filter_input(INPUT_POST, 'pword', FILTER_SANITIZE_STRING);

        $hashedPassword = password_hash($pword, PASSWORD_DEFAULT);

        if ($firstname == !null) {
            $newUser = new User();
            $newUser->setName($firstname);
            $newUser->setSurname($srname);
            $newUser->setPassword($hashedPassword);
            $id = \RossNolan\User::insert($newUser);
            echo 'Thanks for signing up, we will proceed to send you annoying emails. ';
        }

        $arrayArgs = array();
        $template = 'signup';
        $outPut = $twig->render($template . '.php.twig', $arrayArgs);
        echo $outPut;
    }

    /**
     * logout page
     * @param $twig
     */
    public function logoutAction($twig)
    {
        unset($_SESSION['user']);
        $template = 'index';
        $outPut = $twig->render($template . '.php.twig');
        echo $outPut;
        echo 'Goodbye and thank you very much!';
    }

    /**
     * list page
     * @param \Twig_Environment $twig
     */
    public function listAction(\Twig_Environment $twig)
    {
        $products = \RossNolan\Product::getAll();

        $array = [
            'products' => $products,
        ];

        $template = 'list';
        $outPut = $twig->render($template . '.php.twig', $array);
        echo $outPut;
    }

    /**
     * sitemap page
     * @param \Twig_Environment $twig
     */
    public function sitemapAction(\Twig_Environment $twig)
    {
        $array = [];
        $template = 'sitemap';
        $outPut = $twig->render($template . '.php.twig');
        echo $outPut;
    }

    /**
     * kill session
     */
    public function killSession()
    {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(),
                '', time()-42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        //session_destroy();
    }

    /**
     * kill counter
     */
    public function forgetSession()
    {
        $this->killSession();
        print 'SESSION has been destroyed - all session data deleted';
        print '<p><a href="index.php">back to home page</a>';
    }

    /**
     * Counter new hit
     */
    public function newHit()
    {
        $pageHits = 0;
        if (isset($_SESSION['counter'])) {
            $pageHIts = $_SESSION['counter'];
        }

        $pageHits++;
        $_SESSION['counter']= $pageHits;

        print "<p> Counter (number of page hits): $pageHits</p>";
        print '<p>session = ' . session_id();
        print '<hr><a href="/">revisit this home page again</a>';
        print '<hr><a href="/index.php?action=restartSession">restart session</a>';
    }
}
