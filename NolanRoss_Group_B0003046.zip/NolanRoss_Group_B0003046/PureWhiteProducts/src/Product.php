<?php
/**
 * the name space
 */
namespace RossNolan;
/**
 * use thses class`s
 */
use Mattsmithdev\PdoCrud\DatabaseTable;

/**
 * This is the product class
 * Class Product this is my product class
 * @package RossNolan this is my product class
 */
class Product extends DatabaseTable
{
    /**
     * id int
     * @var int
     */
    private $id = -1;
    /**
     * description string
     * @var string
     */
    private $description ='a';
    /**
     * price string
     * @var string
     */
    private $price = 00.00;

    /**
     * get price method
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * set price method
     * @param mixed $price
     */
    public function setPrice($price)
    {
        if ($price >=0) {
            $this->price = $price;
        } else {
            $this->price = 00.00;
        }
    }
    /**
     * get id method
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * set id method
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     *set description method
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * get description method
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }
}
